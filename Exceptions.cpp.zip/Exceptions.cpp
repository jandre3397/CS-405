#include <iostream>
#include <stdexcept> // For standard exceptions
#include <exception> // For std::exception base class

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom Exception: Something went wrong!";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // TODO: Throw any standard exception
    throw std::runtime_error("Standard Exception: Error in do_even_more_custom_application_logic()");
    
    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) { 
        // Catch standard exceptions
        std::cerr << "Exception caught in do_custom_application_logic(): " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors
    if (den == 0) {
        throw std::domain_error("Division by zero error.");
    }
    return num / den;
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& e) {
        std::cerr << "Exception caught in do_division(): " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cerr << "CustomException caught in main(): " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Standard exception caught in main(): " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Unknown exception caught in main()." << std::endl;
    }

    return 0;
}
