#include <iostream>     
#include <limits>       
#include <typeinfo>

/// <summary>
/// Template function to add numbers while preventing overflow.
/// </summary>
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& result)
{
    result = start;
    
    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (increment > 0 && result > std::numeric_limits<T>::max() - increment) {
            return false;  // Overflow detected
        }
        result += increment;
    }

    return true;  // No overflow occurred
}

/// <summary>
/// Template function to subtract numbers while preventing underflow.
/// </summary>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& result)
{
    result = start;
    
    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (decrement > 0 && result < std::numeric_limits<T>::lowest() + decrement) {
            return false;  // Underflow detected
        }
        result -= decrement;
    }

    return true;  // No underflow occurred
}

/// <summary>
/// Function to test for overflow scenarios.
/// </summary>
template <typename T>
void test_overflow()
{
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    T result;
    bool success = add_numbers<T>(start, increment, steps, result);
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    if (success) {
        std::cout << +result << " (No Overflow)\n";
    } else {
        std::cout << "Overflow Detected!\n";
    }

    success = add_numbers<T>(start, increment, steps + 1, result);
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    if (success) {
        std::cout << +result << " (No Overflow)\n";
    } else {
        std::cout << "Overflow Detected!\n";
    }
}

/// <summary>
/// Function to test for underflow scenarios.
/// </summary>
template <typename T>
void test_underflow()
{
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    T result;
    bool success = subtract_numbers<T>(start, decrement, steps, result);
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    if (success) {
        std::cout << +result << " (No Underflow)\n";
    } else {
        std::cout << "Underflow Detected!\n";
    }

    success = subtract_numbers<T>(start, decrement, steps + 1, result);
    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    if (success) {
        std::cout << +result << " (No Underflow)\n";
    } else {
        std::cout << "Underflow Detected!\n";
    }
}

/// <summary>
/// Runs overflow tests for different data types.
/// </summary>
void do_overflow_tests(const std::string& star_line)
{
    std::cout << "\n" << star_line << "\n";
    std::cout << "*** Running Overflow Tests ***\n";
    std::cout << star_line << "\n";

    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

/// <summary>
/// Runs underflow tests for different data types.
/// </summary>
void do_underflow_tests(const std::string& star_line)
{
    std::cout << "\n" << star_line << "\n";
    std::cout << "*** Running Underflow Tests ***\n";
    std::cout << star_line << "\n";

    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point of the program.
/// </summary>
int main()
{
    const std::string star_line(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!\n";

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << "\nAll Numeric Underflow / Overflow Tests Complete!\n";
    return 0;
}
