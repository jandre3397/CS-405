#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <stdexcept>

// The global test environment setup and teardown
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}

    void SetUp() override {
        srand(time(nullptr)); // Initialize random seed
    }

    void TearDown() override {}
};

// Create our test class to house shared data between tests
class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count) {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Test that a collection is created successfully
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// Test adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

// Test max size is greater than or equal to size for different entries
TEST_F(CollectionTest, MaxSizeIsGreaterOrEqualToSize) {
    std::vector<int> vec;
    ASSERT_GE(vec.max_size(), vec.size());

    add_entries(1);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(4);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test capacity is greater than or equal to size for different entries
TEST_F(CollectionTest, CapacityIsGreaterOrEqualToSize) {
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection) {
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

// Test resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection) {
    add_entries(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

// Test resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreasesToZero) {
    add_entries(10);
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// Test clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(10);
    collection->clear();
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// Test erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseRemovesElements) {
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// Test reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacity) {
    size_t initial_capacity = collection->capacity();
    collection->reserve(50);
    ASSERT_GE(collection->capacity(), 50);
    ASSERT_EQ(collection->size(), 0);
}

// Negative Test: Test out_of_range exception when calling at() with an invalid index
TEST_F(CollectionTest, ThrowsExceptionOnOutOfBoundsAccess) {
    add_entries(5);
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Custom Test (Positive): Verify the collection maintains insertion order
TEST_F(CollectionTest, MaintainsInsertionOrder) {
    collection->push_back(10);
    collection->push_back(20);
    collection->push_back(30);
    ASSERT_EQ(collection->at(0), 10);
    ASSERT_EQ(collection->at(1), 20);
    ASSERT_EQ(collection->at(2), 30);
}

// Custom Test (Negative): Test for accessing an element in an empty collection
TEST_F(CollectionTest, AccessEmptyCollectionThrowsException) {
    EXPECT_THROW(collection->at(0), std::out_of_range);
}
